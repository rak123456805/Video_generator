// test-edge-tts.js
import { generateSpeech } from "./src/services/tts/index.js";

await generateSpeech(
  "This is a test audio generated using Microsoft Edge Text to Speech.",
  "edge-test.mp3",
  "en"
);

console.log("DONE");

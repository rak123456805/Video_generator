/* src/services/slideVideoService.js */

import path from "path";
import fs from "fs";
import ffmpeg from "fluent-ffmpeg";

export const generateVideoFromSlides = async (
  slideDirPath,
  outputFileName,
  slideDuration
) => {
  const absSlideDir = path.resolve(slideDirPath);
  const outputFile = path.join(process.cwd(), "generated", outputFileName);

  if (!Number.isFinite(slideDuration) || slideDuration <= 0) {
    throw new Error(`Invalid slideDuration: ${slideDuration}`);
  }

  const slides = fs
    .readdirSync(absSlideDir)
    .filter(f => /^slide_\d+\.png$/.test(f));

  if (!slides.length) {
    throw new Error("No slide_*.png files found");
  }

  const framerate = 1 / slideDuration;

  console.log("🎥 FFmpeg input glob:", "slide_*.png");
  console.log("🎥 Framerate:", framerate);

  return new Promise((resolve, reject) => {
    ffmpeg()
      .input(path.join(absSlideDir, "slide_*.png"))
      .inputOptions([
        "-pattern_type glob",
        `-framerate ${framerate}`
      ])
      .outputOptions([
        "-c:v libx264",
        "-pix_fmt yuv420p",
        "-r 30",
        "-movflags +faststart"
      ])
      .on("start", () => {
        console.log("🎥 FFmpeg started for silent video");
      })
      .on("end", () => {
        console.log("✅ Silent video generated successfully");
        resolve(outputFile);
      })
      .on("error", err => {
        console.error("❌ FFmpeg error:", err.message);
        reject(err);
      })
      .save(outputFile);
  });
};

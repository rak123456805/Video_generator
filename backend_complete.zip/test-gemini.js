/* test-gemini.js */
import axios from 'axios';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

const API_KEY = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;

async function listGeminiModels() {
    if (!API_KEY) {
        console.error("❌ Error: No API Key found in .env file.");
        return;
    }

    // This URL asks Google to list all models available to your specific API key
    const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${API_KEY}`;

    console.log("🔍 Fetching available Gemini models for your API key...");

    try {
        const response = await axios.get(url);
        const models = response.data.models;

        console.log("\n✅ SUCCESS! Your API Key is working.");
        console.log("-----------------------------------------");
        console.log("AVAILABLE MODELS FOR GENERATE CONTENT:");
        
        const validModels = models.filter(m => 
            m.supportedGenerationMethods.includes('generateContent')
        );

        validModels.forEach(m => {
            console.log(`- ID: ${m.name.split('/')[1]}`);
            console.log(`  Name: ${m.displayName}`);
            console.log(`  Description: ${m.description}\n`);
        });

        if (validModels.length > 0) {
            console.log("-----------------------------------------");
            console.log(`👉 Recommendation: Use "${validModels[0].name.split('/')[1]}" in your scriptService.js`);
        }

    } catch (error) {
        console.error("❌ FAILED to fetch models.");
        if (error.response) {
            console.error(`Status: ${error.response.status}`);
            console.error(`Message: ${error.response.data.error.message}`);
        } else {
            console.error(error.message);
        }
    }
}

listGeminiModels();
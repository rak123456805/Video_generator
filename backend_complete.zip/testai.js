import dotenv from "dotenv";
dotenv.config();

const API_KEY = process.env.GOOGLE_API_KEY;

if (!API_KEY) {
  console.error("❌ GOOGLE_API_KEY not found in .env");
  process.exit(1);
}

// ✅ USE A MODEL THAT YOUR KEY SUPPORTS
const url =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" +
  API_KEY;

async function run() {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [{ text: "Respond with exactly: GENERATOR_READY" }],
          },
        ],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("❌ API ERROR:", JSON.stringify(data, null, 2));
      return;
    }

    const text =
      data.candidates?.[0]?.content?.parts?.[0]?.text;

    console.log("--------------------------------");
    console.log("SUCCESS:", text);
    console.log("--------------------------------");
  } catch (err) {
    console.error("❌ REQUEST FAILED:", err.message);
  }
}

run();

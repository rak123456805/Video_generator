/* src/routes/videoRoutes.js */

import express from "express";
import {
  analyzeTopic,
  generateCrashCourse,
  generateFullCoursePart
} from "../controllers/videoController.js";

const router = express.Router();

/**
 * POST /check-feasibility
 * Check if the topic can be taught in the given duration.
 */
router.post("/check-feasibility", analyzeTopic);

/**
 * POST /generate-crash-course
 * Generate a concise summary video.
 */
router.post("/generate-crash-course", generateCrashCourse);

/**
 * POST /generate-full-course
 * Generate a specific part of a detailed course series.
 */
router.post("/generate-full-course", generateFullCoursePart);

export default router;

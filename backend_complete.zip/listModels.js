import dotenv from "dotenv";
dotenv.config();

const API_KEY = process.env.GOOGLE_API_KEY;

if (!API_KEY) {
  console.error("❌ GOOGLE_API_KEY not found in .env");
  process.exit(1);
}

const url =
  "https://generativelanguage.googleapis.com/v1beta/models?key=" +
  API_KEY;

async function run() {
  try {
    const res = await fetch(url);
    const data = await res.json();

    if (!res.ok) {
      console.error("❌ API ERROR:");
      console.error(JSON.stringify(data, null, 2));
      return;
    }

    console.log("✅ MODELS AVAILABLE FOR THIS API KEY:\n");

    data.models.forEach((m) => {
      console.log(
        "-",
        m.name,
        "| supports generateContent:",
        m.supportedGenerationMethods?.includes("generateContent")
      );
    });
  } catch (err) {
    console.error("❌ REQUEST FAILED:", err.message);
  }
}

run();
